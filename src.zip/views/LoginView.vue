<template>
    <h1>登录界面</h1>
</template>

<script>
    export default {
        name: "LoginView"
    }
</script>

<style scoped>

</style>