<template>
    <h1>搜索</h1>
</template>

<script>
    export default {
        name: "SearchView"
    }
</script>

<style scoped>

</style>