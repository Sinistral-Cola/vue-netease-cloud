<template>
    <HeaderCom/>
    <h1>视频</h1>
</template>

<script>
    import HeaderCom from "@/components/header/HeaderCom";
    export default {
        name: "RadioView",
        components: {HeaderCom}
    }
</script>

<style scoped>

</style>