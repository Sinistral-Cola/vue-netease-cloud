<template>
    <HeaderCom/>
    <h1>我的</h1>
</template>

<script>
    import HeaderCom from "@/components/header/HeaderCom";
    export default {
        name: "ProfileView",
        components: {HeaderCom}
    }
</script>

<style scoped>

</style>